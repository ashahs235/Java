package com.example.SpringDataJPA;

import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import com.example.SpringDataJPA.model.Student;

@Repository
//JpaRepository<T, ID> : JpaRepository<Student, int> : <class type, primary key type>
public interface StudentRepo extends JpaRepository<Student, Integer> {
	//JPA Query Language JPQL : we use class names, not table names
	//s is an object, name is a variable
	//works even if below query is not there but not for all : Query DSL : Domain Specific Language : JPA creates methods behind the scene using DSL
	//@Query("select s from Student s where s.name = ?1") //? is replaced by a name, 1, 2, 3 for multiple variables
	List<Student> findByName(String name);
	
	List<Student> findByMarks(int marks);
	
	List<Student> findByMarksGreaterThan(int marks);

}
