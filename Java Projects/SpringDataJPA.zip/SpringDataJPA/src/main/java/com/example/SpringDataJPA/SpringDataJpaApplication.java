package com.example.SpringDataJPA;

import java.util.Optional;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;

import com.example.SpringDataJPA.model.Student;

@SpringBootApplication
public class SpringDataJpaApplication {

	public static void main(String[] args) {
		ApplicationContext context = SpringApplication.run(SpringDataJpaApplication.class, args);
		
		StudentRepo repo = context.getBean(StudentRepo.class);
		
		Student s1 = context.getBean(Student.class);
		Student s2 = context.getBean(Student.class);
		Student s3 = context.getBean(Student.class);
		
		s1.setRollNo(1);
		s1.setName("Asha");
		s1.setMarks(20);
		
		s2.setRollNo(2);
		s2.setName("Yash");
		s2.setMarks(100);
		
		s3.setRollNo(3);
		s3.setName("AshVik");
		s3.setMarks(55);
		
		//methods : navigate JPARepository interface : CRUD
		repo.save(s1);
		repo.save(s2);
		repo.save(s3);
		
		repo.delete(s3);
		
		System.out.println("findAll " + repo.findAll());
		System.out.println("id " + repo.findById(1)); //Optional<T> findById(ID id); so no null pointer exception
		
		//Student s = repo.findById(10);
		//Type mismatch: cannot convert from Optional<Student> to Student
		Optional<Student> s = repo.findById(10); 
		System.out.println("blank object " + s.orElse(new Student())); //if null then print blank object
		
		System.out.println("findByName " + repo.findByName("Yash")); //findByName() is not there, so write a query in StudentRepo class
		
		System.out.println("findByMarks " + repo.findByMarks(55));
		
		System.out.println("findByMarksGreaterThan " + repo.findByMarksGreaterThan(25));
	}

}
