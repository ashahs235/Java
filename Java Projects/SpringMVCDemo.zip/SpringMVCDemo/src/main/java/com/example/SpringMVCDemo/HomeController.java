package com.example.SpringMVCDemo;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

@Controller //Spring framework calls this Controller
public class HomeController 
{
	@RequestMapping("/")
	public String home()
	{
		System.out.println("----------home-----------");
		return "index"; 
		//file gets downloaded with jsp content in it bcoz Spring doesn't support JSP
		//so add Tomcat Jasper dependency from mvn repository : convert JSP into servlet
	}
	
	//accepting req : Servlet way
//	@RequestMapping("add")
//	public String add(HttpServletRequest req, HttpSession session)
//	{
//		int num1 = Integer.parseInt(req.getParameter("num1")); //num1 is String
//		int num2 = Integer.parseInt(req.getParameter("num2"));
//		int result = num1 + num2;
//		System.out.println(result); //send result to jsp page : so HttpSession as a 2nd parameter
//		session.setAttribute("result", result); //adding result data in session (name of the variable, actual data)
//		return "result.jsp";
//	}
	
	//accepting req : SPRING way : NO need to use HttpServletRequest object if we get values (num1 & num2) from url
	//@RequestMapping("add")
	//public String add(int num1, int num2, HttpSession session) //either use the same variable names OR @RequestParam
	//public String add(@RequestParam("num1") int num, int num2, HttpSession session) //assign data of num1 to num
//	public String add(@RequestParam("num1") int num1, @RequestParam("num2") int num2, HttpSession session) //if both names are same, keeping only @RequestParam works
//	{
//		int result = num1 + num2 + 1; //num + num2;
//		System.out.println(result); //send result to jsp page : so HttpSession as a 2nd parameter
//		session.setAttribute("result", result); //adding result data in session (name of the variable, actual data)
//		return "result.jsp";
//	}
	
	//removing HttpSession, using Model
//	@RequestMapping("add")
//	public String add(@RequestParam("num1") int num1, @RequestParam("num2") int num2, Model model)
//	{
//		int result = num1 + num2 + 1; //num + num2;
//		System.out.println(result); //send result to jsp page : so HttpSession as a 2nd parameter
//		model.addAttribute("result", result); //model object works fine for data
//		return "result";
//	}
	
	//removing HttpSession, using ModelAndView
	@RequestMapping("add")
	public ModelAndView add(@RequestParam("num1") int num1, @RequestParam("num2") int num2, ModelAndView mv)
	{
		int result = num1 + num2 + 1; //num + num2;
		System.out.println(result); //send result to jsp page : so HttpSession as a 2nd parameter
		mv.addObject("result", result);
		mv.setViewName("result");
		return mv; //return mv object : View Resolver looks for 2 things : data & view
	}
	
	@RequestMapping("addAlien")
//	public ModelAndView addAlien(@RequestParam("aid") int aid, @RequestParam("aname") String aname, ModelAndView mv)
//	{
//		Alien alien = new Alien();
//		alien.setAid(aid);
//		alien.setAname(aname);
//		
//		mv.addObject("alien", alien);
//		mv.setViewName("result");
//		return mv; //return mv object : View Resolver looks for 2 things : data & view
//	}
	
	//if values are too many, we can't add one by one & we have Alien class representing those values
	//public String addAlien(@ModelAttribute("alien1") Alien alien) //if "alien1" is mentioned here : doesn't work for alien in result.jsp page (empty)
	public String addAlien(Alien alien)
	{		
		//Spring has to create object & assign values coming from request
		//@ModelAttribute assigns value to Alien object & is optional if name is alien in Controller & result.jsp page
				
		return "result";
	}
	
	@ModelAttribute("course")
	public String courseName()
	{
		return "java";
	}
}
