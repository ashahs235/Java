package com.example.JobAppDB;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JobAppDbApplicationTests {

	@Test
	void contextLoads() {
	}

}
