package com.example.SpringBootRest;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.SpringBootRest.Model.JobPost;
import com.example.SpringBootRest.Service.JobService;

//@Controller // + @ResponseBody
@RestController
@CrossOrigin(origins = "http://localhost:3000") //otherwise Network error
//we say to allow request from this particular url
public class JobRestController 
{
    @Autowired
    private JobService service;

    //@GetMapping("jobPosts") //all jobs
    //@ResponseBody //jakarta.servlet.ServletException: Circular view path [jobPosts]: would dispatch back to the current handler URL [/jobPosts] again. Check your ViewResolver setup! (Hint: This may be the result of an unspecified view, due to default view name generation.)
    
    //Jackson library (available by default) converts List of jobs (objects) to JSON & works only JSON, not XML : so Jackson XML
    //below line is to make the method return only JSON
    @GetMapping(path="jobPosts", produces={"application/json"})
    public List<JobPost> getAllJobs()
    {
        //returned data is response body
        return service.getAllJobs(); //return d data which is List, not view name
    }    

    // @GetMapping("jobPost/3") //hardcoded value
    // public JobPost getJob() //1 job
    // {
    //     return service.getJob(3);
    // } 

    //dynamic value : check in postman
    @GetMapping("jobPost/{postId}") 
    public JobPost getJob(@PathVariable("postId") int postId)
    {
        return service.getJob(postId);
    } 

    @PostMapping("jobPost")
    //@PostMapping(path="jobPost", consumes={"application/xml"})
    public JobPost addJob(@RequestBody JobPost jobPost)
    {
        service.addJob(jobPost);
        //return jobPost; //bcoz it's not a good way
        return service.getJob(jobPost.getPostId());
    }

    @PutMapping("jobPost")
    public JobPost updateJob(@RequestBody JobPost jobPost)
    {
        service.updateJob(jobPost);
        return service.getJob(jobPost.getPostId());
    }

    @DeleteMapping("jobPost/{postId}")
    public String deleteJob(@PathVariable("postId") int postId)
    {
        service.deleteJob(postId);
        return "deleted";
    }

}
