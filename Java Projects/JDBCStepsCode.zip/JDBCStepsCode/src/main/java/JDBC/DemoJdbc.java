package JDBC;

//Step1
import java.sql.*;

public class DemoJdbc 
{
	public static void main(String[] args) throws ClassNotFoundException, SQLException 
	{
		/*
		 * import packages
		 * load & register Driver class
		 * Create Connection
		 * Create Statement
		 * Execute Statement
		 * Process the result data
		 * close the costly resources
		 */
		
		String url = "jdbc:postgresql://localhost:5432/demo";
		String uname = "postgres";
		String pass = "1111";
		//String sql = "select sname from student where sid=1";
		String sql = "select * from student"; //to fetch getInt
		
		//Step 2
		Class.forName("org.postgresql.Driver"); //not compulsory
		
		//Step Connection Interface : look for utility class DriverManager
		//getConnection : 3 parameters : url, username, password of database
		Connection con = DriverManager.getConnection(url, uname, pass);
		System.out.println("Connection established");
		
		Statement st = con.createStatement();
		ResultSet rs = st.executeQuery(sql); //for select executeQuery
		//other methods : execute, executeQuery, executeUpdate
		//System.out.println("result " + rs.next()); //next() is boolean : whether new current row is valid
		
		rs.next(); //next is 1st row
		String idstring = rs.getString(1); //just trying : column name or column number can be mentioned
		int id = rs.getInt("sid");
		String name = rs.getString("sname"); 
		System.out.println("id " + id + " idstring " + idstring + " name of student " + name);
		System.out.println(rs); ////org.postgresql.jdbc.PgResultSet@67d48005
		
		while(rs.next())
		{
			System.out.print(rs.getInt(1) + " - ");
			System.out.print(rs.getString(2) + " - ");
			System.out.println(rs.getInt(3) + " ");
		}
		
		con.close();
		System.out.println("Connection closed");
	}

}
