package JDBC;

//Step1
import java.sql.*;

public class PrepStmt 
{
	public static void main(String[] args) throws ClassNotFoundException, SQLException 
	{
		
		//if data comes from user
		int sid = 203;
		String sname = "Rajahuli";
		int marks = 50;
		
		String url = "jdbc:postgresql://localhost:5432/demo";
		String uname = "postgres";
		String pass = "1111";

		String sql = "insert into student values (?, ?, ?)"; 
		//we can't add the above variables, bcoz of double quotes ", 
		//String concatenation is complex bcoz of existing single quotes in SQL query (5, 'KGF', 108)
		

		Class.forName("org.postgresql.Driver"); 

		Connection con = DriverManager.getConnection(url, uname, pass);
		
		PreparedStatement st = con.prepareStatement(sql);
		st.setInt(1, sid);
		st.setString(2, sname);
		st.setInt(3, marks);
		st.execute();
		System.out.println(st);
		System.out.println("executed");
		  	
		//always use PreparedStatement for SELECT query with WHERE condition
		
		con.close();
	}

}
