package JDBC;

//Step1
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class CRUDJdbc
{
	public static void main(String[] args) throws ClassNotFoundException, SQLException
	{
		String url = "jdbc:postgresql://localhost:5432/demo";
		String uname = "postgres";
		String pass = "1111";
		String sql = "select * from student";
		//String sql = "insert into student values (5, 'KGF', 108)";
		//String sql = "update student set sname='KGF2' where sid=5";
		//String sql = "delete from student where sid=5";

		Class.forName("org.postgresql.Driver");

		Connection con = DriverManager.getConnection(url, uname, pass);
		System.out.println("Connection established");

		Statement st = con.createStatement();
		boolean status = st.execute(sql); //navigate : boolean execute, returns true only for SELECT
		//execute returns resultSet if it's a SELECT query, it returns count for insert/update query
		System.out.println("status " + status); //insert

		con.close();
		System.out.println("Connection closed");
	}

}
