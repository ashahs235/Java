insert into student (rollno, name, marks) values (2, 'Yash', 8055);
insert into student (rollno, name, marks) values (3, 'Arvi', 55);
insert into student (rollno, name, marks) values (4, 'Ashvik', 89);