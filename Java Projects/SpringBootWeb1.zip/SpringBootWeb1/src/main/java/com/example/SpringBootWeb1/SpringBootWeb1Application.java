package com.example.SpringBootWeb1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootWeb1Application {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootWeb1Application.class, args);
	}
}
