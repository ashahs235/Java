package com.servlet.ServletCode;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

//@WebServlet("/Hello") : external tomcat
public class HelloServlet extends HttpServlet 
{
	//doGet()
	public void service(HttpServletRequest req, HttpServletResponse res) throws IOException
	{
		System.out.println("in service");
		
		res.setContentType("text/html");
		
		//Responding to the Client
		//res.getWriter().println("servlet is working");
		
		PrintWriter out = res.getWriter();
		out.println("<h2>servlet is working</h2>");
	}
}
