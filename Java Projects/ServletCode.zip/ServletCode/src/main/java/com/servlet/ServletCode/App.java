package com.servlet.ServletCode;
import org.apache.catalina.Context;
import org.apache.catalina.LifecycleException;
import org.apache.catalina.startup.Tomcat;

public class App 
{
    public static void main(String[] args) throws LifecycleException 
    {
        System.out.println("Hello World!");
        Tomcat tomcat = new Tomcat();
        tomcat.setPort(8080);
        
        //Mapping tomcat : telling tomcat about HelloServlet class
        Context context = tomcat.addContext("", null); //(application name, directory) : 
        //application name is default : same application
        //we don't like to create new directory : so null
        
        Tomcat.addServlet(context, "HelloServlet", new HelloServlet()); //(context, servletName, which class)
        context.addServletMappingDecoded("/hello", "HelloServlet"); //(url, servletName) : servletName can be anything
    
        //Start server after mapping
        tomcat.start();
        tomcat.getServer().await(); //telling server to wait if it is exiting
    }
}
