package classes;

public interface Computer {

	void compile();

}