package classes;

import org.springframework.context.annotation.Primary;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

//@Component("comD") //different names instead of lowercase class names
@Component
@Primary //works only if there is NO @Qualifier, Q is ahead of P
@Scope("prototype") //Desktop object is NOT created
public class Desktop implements Computer
{
	public Desktop()
	{
		System.out.println("Desktop object created");
	}
	public void compile()
	{
		System.out.println("compiling in Desktop..");
	}
}
