package classes;

import org.springframework.stereotype.Component;

@Component //bcoz we want Spring to create the object of the below class
public class Laptop implements Computer
{
	public Laptop()
	{
		System.out.println("Laptop object created");
	}
	
	public void compile()
	{
		System.out.println("compiling in Laptop..");
	}
}
