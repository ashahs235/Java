package classes;

import java.beans.ConstructorProperties;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
public class Alien 
{
	//int age;
	@Value("31") //values can be injected from property files better than hardcoding private int age=30;
	private int age; //SETTER INJECTION : age is a property
	//either private int age = 27; OR obj1.setAge(28); in App.java, but we're injecting : so in spring.xml property 
	
	//Object reference variable injection
	//private Laptop lap; // = new Laptop(); we don't create object, we inject dependencies in spring.xml
	
	
	public Alien()
	{
		System.out.println("Alien Object created");
	}
//	
//	@ConstructorProperties({"age", "lap"})
//	public Alien(int age, Laptop lap)
//	{
//		System.out.println("para const");
//		this.age = age;
//		this.lap = lap;
//	}
		
	public int getAge() {
		return age;
	}
	
	public void setAge(int age) {
		System.out.println("age SETTER called"); 
		//<property name="age" value="23"></property> <!-- here it's assigning value to SETTER not variable -->
		
		this.age = age;
	}
	

//	public Laptop getLap() {
//		return lap;
//	}
//
//	public void setLap(Laptop lap) {
//		System.out.println("laptop SETTER called");
//		this.lap = lap;
//	}
//
//	public void code() 
//	{
//		System.out.println("coding in Alien Laptop..");
//		lap.compile();
//	}
	
	//----------------COMPUTER---------------------
	
	@Autowired //Field Injection 
	@Qualifier("laptop") //name specified is lowercase letters of class names OR
	//@Qualifier("comD") //OR @Primary for Desktop or Laptop
	private Computer com; //Ambiguity error bcoz of 2 Computer types


	public Computer getCom() {
		return com;
	}

	//OR @Autowired //setter Injection
	public void setCom(Computer com) {
		this.com = com;
	}
	
	public void code() 
	{
		System.out.println("coding in Alien Computer..");
		com.compile();
	}

}
