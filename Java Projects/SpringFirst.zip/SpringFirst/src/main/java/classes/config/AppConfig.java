package classes.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.context.annotation.Scope;

import classes.Alien;
import classes.Desktop;
import classes.Laptop;
import classes.Computer;

@Configuration
@ComponentScan("classes") //mention d base package : @ComponentScan scans & creates objects for all classes with @Component
public class AppConfig 
{
	//like <bean> : Bean name can have multiple names
	//@Bean(name = {"comD", "desktop1", "beast"})
//	@Bean
//	//@Scope("prototype")
//	public Desktop desktop() //to get the object of Desktop
//	{
//		return new Desktop(); //we have to manually create the object bcoz it's Java based configuration
//		//new keyword : Spring is injecting/creating the object, Spring calls this method & manages the object
//	}
//	
//	@Bean
//	@Primary
//	public Laptop laptop()
//	{
//		return new Laptop(); //if 2 Computer types are present : Laptop & Desktop
//		//ERROR : No qualifying bean of type 'classes.Computer' available: expected single matching bean but found 2: desktop,laptop
//		//so add annotation @Qualifier("desktop")
//	}
//	
//	@Bean
//	//@Autowired (@Autowired Computer com) is optional to mention : connecting wire between Alien & Computer i.e., Desktop
//	public Alien alien(Computer com) //(@Qualifier("desktop") Computer com) OR @Primary for above beans
//	(@Qualifier("desktop") : mention the name of the object we want to refer to : desktop	
//	{
//		Alien obj = new Alien();
//		obj.setAge(25);
//		obj.setCom(com); //obj.setCom(desktop()); :- tightly coupled : so Computer object which is Desktop above
//		return obj;
//	}
	
}
