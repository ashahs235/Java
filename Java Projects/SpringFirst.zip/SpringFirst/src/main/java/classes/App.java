package classes;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import classes.config.AppConfig;

public class App 
{
	public static void main(String[] args) 
	{
		System.out.println("hi");
		
		//JAVA based config
		ApplicationContext context = new AnnotationConfigApplicationContext(AppConfig.class);
		//independent class, Bean name : bean name can be any name : default name is bean method name : desktop()
		//Desktop dt = context.getBean("desktop", Desktop.class);
//		Desktop dt2 = context.getBean(Desktop.class);
//		Desktop dt1 = context.getBean(Desktop.class); //by default every bean in singleton : only once
		//prototype : as many "getBean" are there
		//dt2.compile();
		
		//ALIEN : Autowire
		Alien obj1 = context.getBean(Alien.class); 
		System.out.println("age is "+obj1.getAge());
		obj1.code(); //code() is dependent on compile  which is Computer, so ERROR
		//Exception in thread "main" java.lang.NullPointerException: Cannot invoke "classes.Computer.compile()" because "this.com" is null
		//so setCom in AppConfig
		
		
		
		
		
		//-----------------------------------------------------------------------------------------------
		
//		Alien obj = new Alien();
//		obj.code();
		
		//Spring helps to get Alien object without creating
		//XML BASED CONFIG
		//ApplicationContext context = new ClassPathXmlApplicationContext("spring.xml"); //creates Container
		//at above line, object gets created : it says go to spring.xml & create object that is in <bean> for SINGLETON
		//but for PROTOTYPE, object is not created
		
//		Alien obj1 = (Alien) context.getBean("alien1"); //getBean gives type of object from IoC container, so cast it to Alien
//		obj1.age=21;
//		System.out.println("obj1 "+ obj1.age);
//		obj1.code();
//			
//		Alien obj2 = (Alien) context.getBean("alien1");
//		System.out.println("obj2 " + obj2.age); //21 for both object references bcoz <bean> for Alien is ONCE
//		//21 for singleton by default, 0 for prototype
//		obj2.code();
		
		//EVEN IF getBean is twice, Alien object is created ONCE for Singleton scope (default scope)
		//prototype (creates new object every time for getBean()) : whenever we ask to create
		
		//---------------------------------------------------------------------
		
		//SETTER INJECTION
		
		//Alien obj1 = (Alien) context.getBean("alien1"); //Object typecasted to Alien
		
		//getBean by type
		//Alien obj1 = context.getBean("alien1", Alien.class);
		//obj1.setAge(28);
		//System.out.println("obj1 "+ obj1.getAge());
		//obj1.code();
		
		//Computer com = context.getBean(Computer.class); //works for Desktop.class
		//ERROR for Computer.class No qualifying bean of type 'classes.Computer' available: expected single matching bean but found 2: comL,classes.Desktop#0
		//specify primary for any of the beans in spring.xml
		
		//Desktop objD = (Desktop) context.getBean("comD"); //singleton : explicitly created object which is present in Spring IoC container
		//Desktop objD = context.getBean(Desktop.class); //Desktop bean is present in spring.xml but problem for Computer.class above
	} 
}
