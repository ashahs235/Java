package com.example.demo.service;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.example.demo.model.Laptop;
import com.example.demo.repo.LaptopRepository;

@Service //same like @Component : manages bean
public class LaptopService 
{
	@Autowired //Field injection
	private LaptopRepository repo;
	
	public void addLaptop(Laptop lap) 
	{
		System.out.println("Add laptop called");
		repo.save(lap);
	}
	
	public boolean isGoodForProgramming(Laptop lap)
	{
		return true;
	}
}
