package com.example.demo.model;

public interface Computer 
{
	void compile();
}
