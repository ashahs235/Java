package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.ComponentScan;
import com.example.demo.model.Alien;
import com.example.demo.model.Laptop;
import com.example.demo.service.LaptopService;

import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
//@ComponentScan(basePackages = "com.example") //error before bcoz of package mismatch
public class SpringBootFirstApplication {

	public static void main(String[] args) {
		//SpringApplication.run(SpringBootFirstApplication.class, args);
		ApplicationContext context = SpringApplication.run(SpringBootFirstApplication.class, args);
		
		//Alien obj = new Alien();
		//call object from IoC container : object is Bean
//		Alien obj = context.getBean(Alien.class);
//		System.out.println("age " + obj.getAge());
//		obj.code();
		
//		Alien obj1 = context.getBean(Alien.class);
//		obj1.code();
		
		//ARE THESE 2 ALIEN OBJECTS SAME OR DIFFERENT : prototype/singleton
		
		LaptopService service = context.getBean(LaptopService.class);
		
		Laptop lap = context.getBean(Laptop.class);
		service.addLaptop(lap);
		lap.compile();
	}

}
