package com.example.demo.model;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component // This tells Spring to treat this class as a component (bean)
public class Alien 
{
	@Value("30")
	private int age;
	
	private Computer com;

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public Computer getCom() {
		return com;
	}

	@Autowired
	@Qualifier("laptop") //lowercase class name OR @Primary for Components
	public void setCom(Computer com) {
		this.com = com;
	}

	public void code()
	{
		com.compile();
		System.out.println("coding in alien");
	}
}
