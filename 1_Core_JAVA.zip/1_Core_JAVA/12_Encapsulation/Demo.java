class Human
{

    // private int age = 11;
    // private String name = "coder";

    //add setters if the values of the variables aren't assigned
    private int age;
    private String name;
    public int getAge() {
        return age;
    }
    public void setAge(int age) {
        //age = age; //0
        this.age = age;
    }
    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }

    // public int getAge()
    // {
    //     return age;
    // }

    //a is local variable, age is instance variable : this keyword if both variables are SAME
    //The assignment to variable age has no effect
    // public void setAge(int a)
    // {
    //     age = a;
    // }

    // public String getName()
    // {
    //     return name;
    // }

    // public void setName(String n)
    // {
    //     name = n;
    // }

}

public class Demo
{
    public static void main(String[] args) 
    {
        Human obj = new Human();
        //public variables
        // obj.age = 5;
        // obj.name = "Asha";
         //System.out.println(obj.name);

        obj.setAge(20);
        obj.setName("Developer");
        System.out.println(obj.getName() + " : " + obj.getAge());

        
    }
}