class Hello
{
    public static void main(String[] args) 
    {
        // int a = 28; //8 : no op
        // if (a > 10 && a < 20)
        //     System.out.println("hello");

        // else
        // System.out.println("else");

        // System.out.println("bye");

        if (true)
        System.out.println("true");

        if(false)
        System.out.println("false"); //not printed : dead code


        // int x = 8;
        // int y = 17;
        // int z = 6;

        // if (x>y)
        // {
        //     System.out.println(x);
        //     System.out.println("asha");
        // }
        // else
        //     System.out.println(y);

        // if (x>y && x>z)
        // System.out.println(x);

        // else if (y>z && y>x)
        // System.out.println(y);

        // else
        // System.out.println(z);

        //TERNARY
        int n = 5;
        int result = 0;

        // if (n%2==0)
        //     result = 10;
        // else
        //     result = 20;

        //"?:" -> if it's true execute the part of the code after ?, if false execute after :
        //condition ? expression1 : expression2;
        //CONDITION?TRUE:FALSE
        
        result = n%2==0 ? 10 : 20;

        System.out.println("result "+result);


        int x = 5;
        int y = 10;
        int z = 15;

        int max = (x > y) ? ((x > z) ? x : z) : ((y > z) ? y : z);
                //  ? F : z=15 : F : z=15
        System.out.println("The maximum value is " + max);

        
    }
}