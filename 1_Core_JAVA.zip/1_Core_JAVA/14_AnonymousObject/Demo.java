class A
{
    public A()
    {
        System.out.println("Object created");
    }
    public void show()
    {
        System.out.println("in A show");
    }
}

public class Demo
{
    public static void main(String[] args) 
    {
        int marks;
        marks = 99;

        //A obj = new A();
        // A obj; //Reference Creation in Stack area
        // obj = new A(); //Object creation in Heap area
        // obj.show();

        //INSTEAD OF THAT
        //new A(); //Object creation in Heap area WITHOUT reference variable in Stack area - nothing in Stack
        //This type of objects without reference variable are called ANONYMOUS OBJECTS bcoz those object do not have name
        //We can't reuse these objects bcoz everytime new A() : new object gets created, we can reuse only with reference variables 
        new A().show(); 
        new A().show(); //3 objects so far
    }
}