class Laptop
{
    int price;
    String model;
    //String serial; //same price & model, different serial, so skip serial in hashcode() & equals()

    //overriding toString(), otherwise default implmentation from Object class
    public String toString()
    {
        //return "Asha";
        //return (model + " : " + price);
        return model + " : " + price;
    }

    

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + price;
        result = prime * result + ((model == null) ? 0 : model.hashCode());
        return result;
    }

    // @Override
    // public String toString() {
    //     return "Laptop [price=" + price + ", model=" + model + "]";
    // }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        Laptop other = (Laptop) obj;
        if (price != other.price)
            return false;
        if (model == null) {
            if (other.model != null)
                return false;
        } else if (!model.equals(other.model))
            return false;
        return true;
    }

    //our method : since there is no hashcode here, generate equals() from IDE
    // public boolean equals(Laptop that)
    // {
    //     // if(this.model.equals(that.model) && this.price == that.price) //for int price : ==
    //     //     return true;
    //     // else
    //     //     return false;   
        
    //     //simplifying code
    //     return this.model.equals(that.model) && this.price == that.price;
    // }
        

}

public class Demo
{
    public static void main(String[] args) 
    {
        Laptop obj = new Laptop();
        obj.model = "Lenovo Yoga";
        obj.price = 1000;

        System.out.println(obj); //heap memory value Laptop@36baf30c
        System.out.println(obj.toString());

        Laptop obj1 = new Laptop();
        obj1.model = "Lenovo Yoga";
        obj1.price = 1000;

        //check whether 2 objects are equal : reference comparison ==
        boolean reference = obj == obj1;
        System.out.println("reference " + reference); //false, new keyword is always new object

        boolean content = obj.equals(obj1); 
        //false for object class equals() & true for our equals() bcoz equals() in object compares 2 objects based on hexadecimal values 
        //but we want to compare 2 objects based on their values, so we'll override it as above
        System.out.println("content " + content);

        System.out.println(obj1); //heap memory value Laptop@36baf30c
        System.out.println(obj1.toString());

    
    }
}