class Calculator
{
    int num=5; // instance variable
    //n1, n2 are local variables bcoz they are a part of add() & are stored in stack memory
    public int add(int n1, int n2)
    {
        System.out.println(num); //using a var inside method but not declaring
        return n1+n2;
    }
    public int add(int n1, int n2, int n3)
    {
        return n1+n2+n3;
    }
    public double add(double n1, int n2)
    {
        return n1+n2;
    }
}

public class Demo
{
    public static void main(String[] args) 
    {
         int data = 10;
         Calculator obj = new Calculator(); //obj is a reference var
         int r = obj.add(1, 2); // one stack for r var, another new stack for add()
         System.out.println(r);
         int r1 = obj.add(1, 2, 3);
         System.out.println(r1);
         double r2 = obj.add(1.9, 2);
         System.out.println(r2);
         Calculator obj1 = new Calculator();

         obj.num = 8;
         System.out.println("--------");
         System.out.println(obj.num);
         System.out.println(obj1.num);
    }
}