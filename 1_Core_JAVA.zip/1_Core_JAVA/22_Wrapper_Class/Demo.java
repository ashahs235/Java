public class Demo
{
    public static void main(String[] args) 
    {
        int num = 7;
        //Integer num1 = new Integer(9); //strike line bcoz this syntax is depricated
        Integer num2 = 10; //new syntax
        //System.out.println(num1);
        System.out.println(num2);

        int a1 = 4;
        //Integer inta = new Integer(a1); //boxing : storing primitive value into wrapper class
        Integer inta = a1; //Autoboxing : automatic conversion

        System.out.println("inta " + inta);

        //to convert object type to primitive : UNBOXING
        int a2 = inta.intValue();
        System.out.println("a2 " + a2);

        int a3 = inta; //auto-unboxing
        System.out.println("a3 " + a3);

        //to convert String to integer
        String str = "12";
        //System.out.println(str*2); //ERROR
        //parseInt() : to convert str to int
        int num3 = Integer.parseInt(str);
        System.out.println(num3*2);

    }
}