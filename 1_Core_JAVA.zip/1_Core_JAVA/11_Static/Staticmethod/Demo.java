//package Staticmethod;

class Mobile
{
    //Instance or non static variables
    String brand;
    int price;

    //STATIC KEYWORD : making var as CLASS member, not object member
    static String name; //if static var, there is only 1 value i.e., recently assigned variable

    public void show()
    {
        //static var can be used in non static method, to call instance method, always create object of it
        System.out.println(brand + " : " + price + " : " + name);
    }

    public static void show1(Mobile obj)
    {
        //non static variables cannot be used inside static method 
        //bcoz non static var can be different for different objects 
        //but static variable is same for all objects
        //Cannot make a static reference to the non-static field brand
        //Ambiguity as to which object's non static variables to be called
     //   System.out.println(brand + " : " + price + " : " + name);
        System.out.println(obj.brand + " : " + obj.price + " : " + name);
    }
}

public class Demo 
{
    //main() is starting point of the execution, so static
    public static void main(String[] args) 
    {
        //ERROR : Cannot make a static reference to the non-static method show() from the type Mobile
        //Mobile.show();
        

        Mobile obj1 = new Mobile();
        obj1.brand = "Samsung"; //different values for different objects
        obj1.price = 40000;
        Mobile.name = "android";

        Mobile obj2 = new Mobile();
        obj2.brand = "Apple";
        obj2.price = 50000;
        Mobile.name = "iphone";
        

        Mobile.name = "smartphone"; //recently assigned value is o/p

        // obj1.show();
        // obj2.show();

        //to call non static var inside static method
        Mobile.show1(obj1);
        Mobile.show1(obj2);
    }
}
