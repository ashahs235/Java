class Mobile
{
    //Instance or non static variables
    String brand;
    int price;

    //STATIC KEYWORD : making var as CLASS member, not object member
    static String name; //if static var, there is only 1 value i.e., recently assigned variable

    public void show()
    {
        //static var can be used in non static method
        System.out.println(brand + " : " + price + " : " + name);
    }
}

class Demo
{
    public static void main(String[] args) 
    {
        Mobile obj1 = new Mobile();
        obj1.brand = "Samsung";
        obj1.price = 40000;
        obj1.name = "SmartPhone";

        Mobile obj2 = new Mobile();
        obj2.brand = "Apple";
        obj2.price = 50000;
        obj2.name = "IPhone";

      //  obj1.name = "Phone"; //changed for both objects bcoz it's shared by ALL OBJECTS
        //So STATIC var can be called by classname
        //WARNING : The static field Mobile.name should be accessed in a static way

        //if static variable assignment is not done, recent value of "name" is printed
        Mobile.name = "Phone"; //STATIC var : memory is saved bcoz NOT every object will have own copy/value for it

        //System.out.println(obj1.brand); //instead call show()
        obj1.show();
        obj2.show();
    }
}