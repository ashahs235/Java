class Mobile
{
    //Instance or non static variables
    String brand;
    int price;
    static String name; 

    //Constructor executes as many times the object is created
    public Mobile()
    {
        brand = "";
        price = 200;
        //name = "Phone"; //static var : no need to initialise inside constructor bcoz every time a object is created, it gets initialised : so STATIC BLOCK
        System.out.println("in constructor");
    }

    //static block is called only once irrespective of any no of objects created : called first
    //when an object is created : 2 steps : CLASS loading is first, then OBJECT creation, so static is first 
    //if we do not create an object, CLASS is also NOT loaded, so Class.forName() to load the class : FQCN
    
    static
    {
        name = "Phone";
        System.out.println("static block");
    }

    public void show()
    {
        //static var can be used in non static method
        System.out.println(brand + " : " + price + " : " + name);
    }
}

public class Demo {
    public static void main(String[] args) throws ClassNotFoundException 
    {
        //NO O/P if objects are NOT created
        // Mobile obj1 = new Mobile();
        // obj1.brand = "Samsung"; //different values for different objects
        // obj1.price = 40000;
        // Mobile.name = "android";

        Mobile obj2 = new Mobile();
        //Class.forName("Mobile");
    }
    
}
