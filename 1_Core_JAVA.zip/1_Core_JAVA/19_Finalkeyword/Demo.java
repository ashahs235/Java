//final keyword is used with a variable, method, class

//final class Calc
class Calc
{
    public final void show()
    {
        System.out.println("in show Calc");
    }
    public void add(int a, int b)
    {
        System.out.println(a+b);
    }
}

class AdvCalc extends Calc
{
    public void show()
    {
        System.out.println("in show AdvCalc");
    }
}

class Demo
{
    public static void main(String[] args) 
    {
        // final int num = 8;
        // num = 9; //reassigning : error bcoz final
        // System.out.println(num);
        Calc c = new Calc();
        c.show();
        c.add(8, 9);
    }
}