class Computer
{

}

class Laptop extends Computer
{

}

class A
{
    public void show()
    {
        System.out.println("in A show");
    }
}

class B extends A
{
    public void show()
    {
        System.out.println("in B show");
    }
}

class C extends A
{
    public void show()
    {
        System.out.println("in C show");
    }
}

class Demo
{
    public static void main(String[] args) 
    {
        //B b = new B();
        //A obj = new A(); //reference of A, object of B
        //obj : reference variable
        //type of variable : A

        // A obj = new B();
        // obj.show();


        //DYNAMIC METHOD DISPATCH : based on the object created : child objects for parent reference variables : inheritance is must
        A objA = new A();
        objA.show();

        objA = new B(); //assigning new object to a old variable
        objA.show();

        objA = new C(); //assigning new object to a old variable
        objA.show();

        Computer lap = new Laptop();
        
    }
}