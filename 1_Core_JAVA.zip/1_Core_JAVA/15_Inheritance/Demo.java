class Demo
{
    public static void main(String[] args) 
    {
        VeryAdvCalc obj = new VeryAdvCalc();
        int r1 = obj.add(5, 6);
        int r2 = obj.sub(6, 8);
        int r3 = obj.multi(6, 8);
        int r4 = obj.div(66, 8);
        double r5 = obj.power(2, 2);
        System.out.println(r1 + " " + r2 + " " + r3 + " " + r4 + " " + r5);
    }
}