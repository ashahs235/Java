public class JaggedArray 
{
    public static void main(String[] args) 
    {
        //2 D array
        // int nums[][] = new int[3][] ; //jagged array

        // //specify individually for every column
        // nums[0] = new int[3]; //1st array
        // nums[1] = new int[4]; //2nd array
        // nums[2] = new int[2]; //3rd array

        // for(int i=0; i<nums.length; i++) //outer box
        // {
        //     for(int j=0; j<nums[i].length; j++) //inner box : length of evry row
        //     {
        //        nums[i][j] = (int)(Math.random() * 10); //100
        //        //System.out.println(nums[i][j]);
        //     }
        // }

        // for(int n[] : nums) //n[] is a single dimensional array
        // {
        //     for(int m : n)
        //     {
        //         System.out.print(m + " ");
        //     }
        //     System.out.println();
        // }

        //=====================3 D array ======================

        int nums3[][][]= new int[3][4][5] ; //jagged array

        for(int i=0; i<nums3.length; i++) //outer box
        {
            for(int j=0; j<nums3[i].length; j++) //inner box
            {
               for(int k=0; k<nums3[i][j].length; k++)
               {
                    nums3[i][j][k] = (int)(Math.random() * 10); //100
                    //System.out.println(i + " : " + nums3[i][j][k]);
                    System.out.println("nums3[" + i + "][" + j + "][" + k + "] = " + nums3[i][j][k]);
               }              
            }
        }

        for(int n[][] : nums3) //n[] is a single dimensional array
        {
            for(int m[] : n)
            {
                for(int l : m)
                System.out.print(l + " ");
            }
            System.out.println();
        }

    }
    
}
