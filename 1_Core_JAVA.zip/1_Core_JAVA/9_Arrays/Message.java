class Message{

    public void printMessage(int message) {   
    System.out.println("Message primitive: " + message);   
    }
    
    public void printMessage(Integer message) {  
    System.out.println("Message object: " + message);  
    }
    
    public static void main(String[] args){  
    Message ob=new Message();   
    ob.printMessage(4);    
    
     // Using autoboxing
     ob.printMessage(Integer.valueOf(4)); // This will call the method with Integer parameter

     // Creating an Integer object
     Integer intObj = 4; // Autoboxing
     ob.printMessage(intObj); // This will call the method with Integer parameter

     String password[] = { "XY01", "XY02", "XY03", "XY04"};
    String result =" ";

    for(int i = password.length-1; i>=2; i--) {

    result = result + password[i];

    }

    System.out.println("test" + result); 
    }
    }