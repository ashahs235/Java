public class Demo
{ 
    public static void main(String[] args) 
    {
        // int nums[] = {3, 7, 2, 4};
        // for(int i=0; i<nums.length; i++)
        // {
        //     System.out.println(nums[i]);
        // }

        // int nums1[] = new int[4]; //length
        // nums1[2] = 9;
        // System.out.println(nums1[3]);

        //MULTI-DIMENSIONAL ARRAY - 2D
        int nums2[][] = new int[3][4]; // 3 arrays, each array with 4 elements

        for(int i=0; i<3; i++) //outer box
        {
            for(int j=0; j<4; j++) //inner box
            {
               nums2[i][j] = (int)(Math.random() * 10); //100
               System.out.println(nums2[i][j]); //straight line
            }
        }
        System.out.println("=======================");
        for(int i=0; i<3; i++) //outer box
        {
            for(int j=0; j<4; j++) //inner box
            {
                System.out.print(nums2[i][j] + " "); //0000 o/p so fetch random values : Math.random(); return type of random() is double
            }
            System.out.println();
        }

        System.out.println("========Enhanced for loop==========");
        for(int n[] : nums2) //n[] is a single dimensional array, bcoz nums2 is 2D array, we want 1st element that is 1st array, not a variable
        {
            for(int m : n) //m is array elements from n[]
            {
                System.out.print(m + " ");
            }
            System.out.println();
        }
    }
    
}