public class FirstDigitExample {
    public static void main(String[] args) {
        int[] a = {12, 23, 34, 56};

        // Loop through each element in the array
        for (int number : a) {
            int firstDigit = getFirstDigit(number);
            System.out.println("First digit of " + number + " is: " + firstDigit);

            System.out.println("-------------");

            int secondDigit = getSecondDigit(number);
            System.out.println("Second digit of " + number + " is: " + secondDigit);

            System.out.println("-------------");
        }
    }

    // Method to get the first digit of a number
    public static int getFirstDigit(int number) {
        // Continue dividing by 10 until number is a single digit
        while (number >= 10) {
            number /= 10;
        }
        return number;
    }

    public static int getSecondDigit(int number) {
        while(number >= 10)
        {
            number %= 10;
        }
        return number;
    }
}
