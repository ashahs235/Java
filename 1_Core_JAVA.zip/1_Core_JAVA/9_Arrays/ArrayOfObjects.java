class Student
{
    int rollno;
    String name;
    int marks;
}

public class ArrayOfObjects 
{
    public static void main(String[] args) 
    {
        Student s1 = new Student();
        s1.rollno = 1;
        s1.name = "Asha";
        s1.marks = 98;

        Student s2 = new Student();
        s2.rollno = 2;
        s2.name = "Asha1";
        s2.marks = 89;

        Student s3 = new Student();
        s3.rollno = 3;
        s3.name = "Asha2";
        s3.marks = 99;
        System.out.println("s2 " + s2); //reference is the o/p : Student@f6f4d33
        System.out.println(s1.name + " : " + s1.marks);

        //Student array which holds 3 Student refernces, NOT object creation
        Student students[] = new Student[3];
        students[0] = s1;
        students[1] = s2;
        students[2] = s3;

        for(int i=0; i<students.length; i++)
        {
            System.out.println(students[i].name + " : " + students[i].marks);
        }

        //for(type variable name : array name)
        for(Student stud : students)
        {
            //System.out.println(stud); //Student@3af49f1c 
            System.out.println(stud.name + " : " + stud.marks);
        }


        //==========================ENHANCED FOR LOOP====================
        int nums[] = new int[5];
        nums[0] = 1;
        nums[1] = 2;
        nums[2] = 3;
        nums[3] = 4;

        for(int i=0; i<nums.length; i++) //no need of int to specify length of an array
        {
            System.out.println(nums[i]);
        }

        for(int n : nums)
        {
            System.out.println(n);
        }
    }
}
