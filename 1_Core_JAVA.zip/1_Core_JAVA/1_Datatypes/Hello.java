class Hello
{
    public static void main(String a[])
    {
        int num = 4;
        // System.out.println("num is " +num);
        // System.out.println("Hello World");
        // System.out.println(8*9);
        byte by = 127; //129 gives error
        short sh = 558;
        long l = 5854l;
        float f = 1.2f;
        double d = 1.2;
        char c1 ='k';
        char y ='2'; //char can be number also. chars are called literals
        boolean b = true;

        //LITERALS
        int binary = 0b101; //binary format : 2
        System.out.println("binary " +binary);

        int hexadecimal = 0x7E;
        System.out.println("hexadecimal " +hexadecimal);

        int zero_count = 10_00_00_000; //undescore to count zeroes : easy
        System.out.println("zero_count " +zero_count);

        double dnum = 56; //int gets converted into double
        System.out.println("double number 1 " + dnum);

        double dnum1 = 12e10; //epsilon
        System.out.println("double number 2 " + dnum1);

        char c = 'a';
        c++; //c = c+1;
        System.out.println("c is " +c); //b

        System.out.println("===============TYPECASTING===========");
        byte b1 = 127; //if 257 : error
        int a1 = b1;
        System.out.println("a1 "+a1);
        //System.out.println("b1 " +b1);

        int a2 = 12; //byte range
        //byte k = a2; //error : Type mismatch: cannot convert from int to byte
        byte k = (byte)a2;
        System.out.println("k "+k);

        int a3 = 257; //bigger range than byte
        byte k1 = (byte)a3;
        System.out.println("k1 "+k1); //1 : modulus 257%256

        float k2 = 5.6f;
        //int t = k2; //error : Type mismatch: cannot convert from float to int
        int t = (int)k2;
        System.out.println("t: "+t); //5

        System.out.println("======TYPE PROMOTION=========");
        byte b11 = 10;
        byte b12 = 30;

        int byte_result = 10*30;
        System.out.println("byte_result : "+byte_result);

        char ch = 'a';
        char result_ch = (char)(ch + 1);
        System.out.println("result_ch "+result_ch); //b
                



    }
}