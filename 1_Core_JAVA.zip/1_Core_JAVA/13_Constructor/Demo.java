class Human
{
    private int age;
    private String name;

    //any ASSIGNMENT or CALCULATION must be done in methods or CONSTRUCTOR : not in the above variables --STANDARD
    //DEFAULT CONSTRUCTOR
    // public Human()
    // {
    //     //blank : default
    // }

    public Human()
    {
        System.out.println("Parameterless Constructor : created by user");
        age = 12;
        name = "asha";
    }

    public Human(int a, String n)
    {
        System.out.println("Parameterized Constructor");
        age = a;
        name = n;
    }

    public int getAge() {
        return age;
    }
    public void setAge(int age) {
        //age = age; //0
        this.age = age;
    }
    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }

}

public class Demo
{
    public static void main(String[] args) 
    {
        //Object creation calls the constructor
        Human obj = new Human();
        Human obj1 = new Human(); //2 objects = 2 times constructor is called
        System.out.println(obj.getName() + " : " + obj.getAge());
        Human obj2 = new Human(2005, "Java");
        System.out.println(obj2.getName() + " : " + obj2.getAge());

        
    }
}