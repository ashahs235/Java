class Hello
{
    public static void main(String[] args) 
    {
        int num = 7;
        int num2 = 15;

        int result = num % num2; //+ - * /
        //System.out.println(result); // division symbol / gives quotient, % gives remainder

        //num = num + 2;
        //num += 3; // +=, not + =
        //num -= 3;
        //num *= 3;

        //INCREMENT BY 1
        //num += 1;
        // num++; //post increment
        // System.out.println("num++ is " +num);
        // ++num;
        // num--; //post decrement
        //num++ & ++num are same if they are individual stmt
        //System.out.println("num-- is " +num);

        //int res = ++num;
        int res = num++; //assign value of num to res & then increment

        //int res = ++num; //increment & assign the incremented value
        System.out.println("num " + num);
        System.out.println("res " + res);

        
    }
}