class Hello
{
    public static void main(String[] args) 
    {
        //to compare 2 values : >, <, ==, !=, <=, >=
        //a=5 : = is assignment operator so == is relational operator

        // double x = 1.5;
        // double y = 6.1;

        //boolean result = x < y; //false if both the values are equal
        // boolean result = x <= y; //<=, <=, !=, ==
        // System.out.println(result);
//=================================================================================

        //LOGICAL OPERATORS
        //SHORT CIRCUIT
        //boolean r = x>y || a>b; //if 1st condition is true, it doesn't check for 2nd
        //boolean r = x>y && a>b; //if 1st condition is false, it doesn't check for 2nd

        int x =7;
        int y = 5;
        int a = 5;
        int b = 9;

        boolean AND_result = x > y && a > b;
        System.out.println("AND_result " + AND_result);

        boolean OR_result = x > y || a > b || a < 1;
        System.out.println("OR_result " + OR_result);

        boolean result = a > b;
        System.out.println(result);
        System.out.println("negation "+!result);

        
    }
}