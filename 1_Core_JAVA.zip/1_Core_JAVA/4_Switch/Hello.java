class Hello
{
    public static void main(String[] args) 
    {
        int  n = 1;

        if (n == 1)
            System.out.println("Monday");
        else if (n == 2)
            System.out.println("Tuesday");
        else if (n == 3)
            System.out.println("Wednesday");
        else if (n == 4)
            System.out.println("Thursday");
        else if (n == 5)
            System.out.println("Friday");
        else if (n == 6)
            System.out.println("Saturday");
        else
            System.out.println("Sunday");

        //IF ELSE CONDITION TAKES MORE TIME TO EXECUTE, SO SWITCH
        //switch case value takes only String literal or numerical, not any declared variable
        //case expressions must be constant expressions
        //if else : checking the condition multiple times,
        //switch : matching the case
        //without break, all sops are executed
        //QUIZ : Which conditional statement is used to check multiple possible values of a variable? SWITCH
        int m = 7;
        switch(m)
        {
            case 1 :
                System.out.println("Monday");
                break;
            case 2 :
                System.out.println("Tuesday");
                break;
            case 3 :
                System.out.println("Wednesday");
                break;
            case 4 :
                System.out.println("Thursday");
                break;
            case 5 :
                System.out.println("Friday");
                break;
            case 6 :
                System.out.println("Saturday");
                break;
            case 7 :
                System.out.println("Sunday");
                break;
            default:
                System.out.println("Enter a valid number");
        }
    }
}