class A
{
    public A()
    {
        super();
        System.out.println("in constructor A");
    }

    public A(int n)
    {
        super();
        System.out.println("in constructor A int");
    }
}

class B extends A
{
    public B()
    {
        super(5); //present by default 
        System.out.println("in constructor B");
    }

    public B(int n)
    {
        //super();
        //super(n); //every constructor will have super()
        this();
        System.out.println("in constructor B int");
    }
}

class Demo
{
    public static void main(String[] args) 
    {
        //B obj = new B();
        B obj1 = new B(5); //child class object is created, so parent class default constructor is always called bcoz of super() 
                                //every constructor will have super()
    }
}