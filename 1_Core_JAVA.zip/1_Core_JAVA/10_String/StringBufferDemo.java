public class StringBufferDemo 
{
    public static void main(String[] args) 
    {
        //mutable string, it gives a buffer size of initial capacity 16
        //StringBuffer sb = new StringBuffer(); //capacity is 16
        StringBuffer sb = new StringBuffer("Asha_s"); //22
        System.out.println(sb.capacity()); 
        System.out.println(sb.length());
        sb.append(" Developer");
        System.out.println(sb);
        sb.deleteCharAt(5);
        sb.insert(6, " Java ");
        System.out.println(sb);

        //Assign StringBuffer data to String : error, so toString
        String str = sb.toString(); 
        System.out.println("str " + str);
    }
}
