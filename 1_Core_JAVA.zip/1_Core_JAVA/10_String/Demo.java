public class Demo
{
    public static void main(String[] args) 
    {
        //String is series of characters, String is a class
        String name =  "Asha";
        String name1 = new String(); //bcoz String is a class
        System.out.println("name " + name);
        System.out.println(name1); //prints nothing : empty

        String name2 = new String("asha_s"); //heap area
        System.out.println("name2 " + name2);
        System.out.println(name2.hashCode()); //-1408540193
        System.out.println(name2.charAt(2));
        System.out.println(name2.concat(" developer"));

        //instead of new String, directly assign String name =  "Asha"; //it's equal to object creation

        String name_var = "asha"; //string is created in scp with an address, it may be removed later if there is no ref: Garbage Collection
        name_var = name_var + " developer"; //new string object is created in scp area with different address
        //& new recent address is created for name_var in stack area
        System.out.println("hello " + name_var);

        String s1 = "Asha_S";
        String s2 = "Asha_S"; //s1 & s2 are references pointing to same object in String constant pool 
        //SCP is inside heap. Stack & Heap are a part of JVM.
        //s1 & s2 are having same address (103)
        System.out.println("reference comparison is " + (s1 == s2)); //reference comparison
        System.out.println("content comparison is " + (s1.equals(s2)));
    }
}