class Computer
{
    public void playMusic()
    {
        System.out.println("playing music..");
    }

    public String getMeAPen(int cost)
    {
        if(cost >= 10)
            return "Pen"; //without else condn, code execution stops after 1st return stmt
        // else
        //     return "Nothing";

        return "Nothing";
    }
}

public class Demo
{
    public static void main(String[] args) 
    {
        Computer obj = new Computer();
        obj.playMusic();
        //obj.getMeAPen(10);  //no "Pen" in o/p if called, so assign & print    
        String str = obj.getMeAPen(12);
        System.out.println(str);  
    }
}