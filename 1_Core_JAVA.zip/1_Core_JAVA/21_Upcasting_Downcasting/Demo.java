class A
{
    public void show1()
    {
        System.out.println("show1 A");
    }
}

class B extends A
{
    public void show2()
    {
        System.out.println("show2 B");
    }
}


public class Demo
{
    public static void main(String[] args) 
    {
        // double d = 4.5;
        // int i = (int)d; //Typecasting
        // System.out.println(d);
        // System.out.println(i);

        A obj = new A();
        obj.show1();

        A obj1 = new B(); //object of B, reference of A : execution happens implicitly
        //A obj1 = (A) new B(); //typecaste : upcasting : not compulsory
        obj1.show1(); //obj1 is of type A
        //obj1.show2(); //error : can't be called bcoz reference is A, A has no idea about show2 in B
        //to solve the above error

        //either
        // B obj2 = new B();
        // obj2.show2();

        //or downcasting
        //B obj2 = obj1; //error bcoz obj1 is referring to B object but is of type A
        B obj2 = (B) obj1;
        obj2.show2();
        

    }
}