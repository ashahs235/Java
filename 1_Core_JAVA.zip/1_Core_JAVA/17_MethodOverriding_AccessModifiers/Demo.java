import tools.*;
// is all files, not folder 
//System class is present in java.lang pkg => java.lang pkg is by default imported

// class A
// {
//     public void show()
//     {
//         System.out.println("in show A");
//     }

//     public void config()
//     {
//         System.out.println("in config A");
//     }
// }

// class B extends A
// {
//     public void show()
//     {
//         System.out.println("in show B");
//     }
// }

// class Calc
// {
//     public int add (int n1, int n2)
//     {
//         return n1 + n2;
//     }
// }

// class AdvCalc extends Calc
// {
//     public int add (int n1, int n2)
//     {
//         return n1 + n2 + 1;
//     }
// }

class C extends A //public C is error bcoz we can't have 2 public classes in same file
{
    public void displayDemo()
    {
        System.out.println("protected " + marksA);
    }
}

class Demo
{
    public static void main(String[] args) 
    {
        A objA = new A();
        //System.out.println(objA.marks); //error : if marks in A class is protected
        //objA.displayDemo();

        AdvCalc obj = new AdvCalc();
        int r = obj.add(3, 4);
        System.out.println(r);

        B objB = new B();
        System.out.println(objB.marksB);

    }
}