package tools;
public class A
{
    //public int marks = 80; //make it public bcoz it's called in Demo.java file which is in different package
    
    protected int marksA = 80;

    public void show()
    {
        System.out.println("in show A");
    }

    public void config()
    {
        System.out.println("in config A");
    }
}

class Aa extends A 
{
    public void display()
    {
        System.out.println("Aa" + marksA);
    }
}