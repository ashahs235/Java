package tools;
class Calc 
{
    public int add (int n1, int n2)
    {
        return n1 + n2;
    }
}

class Temp
{
    public void displayA()
    {
        A objA =  new A(); //if commented : sysout(marksA)
        System.out.println("temp class marksA "+objA.marksA);
    }
    
}