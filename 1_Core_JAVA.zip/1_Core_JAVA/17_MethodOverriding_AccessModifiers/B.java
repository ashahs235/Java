public class B
{
    protected int marksPro = 80;
    int marksB = 90; //same package
    public void show()
    {
        System.out.println("in show A");
    }

    public void config()
    {
        System.out.println("in config A");
    }
}