public class Hello 
{
    public static void main(String[] args) 
    {
        //combining all while loop conditions, for loop : 3 different stmts
        //INITIALIZATION; FINALIZATION; UPDATION (INCREMENT/DECREMENT)
        //for(int i=5; i>=1; i--)
        //for(int i=1; i<=4; i++) //0 to <=3 or <4
        // {
        //     System.out.println("hi "+i);
        // }

        //WORKING : checks for condtion i=1; i<=5, executes body & then updates
        // for(int i=1; i<=5; i++)
        // {
        //     System.out.println("Day " + i);
        //     //printing 9am to 5pm
        //     for(int j=1; j<=9; j++)
        //     {
        //         System.out.println(" " + (j+8) + " - " + (j+9)); //String concatenation
        //     }
        // }

        // int i = 1;
        // for(;i<=5;) //;
        // {
        //     System.out.println("Day " + i);
        //     i++;
        // }

        // int a, b;
        // a=b=10;
        // System.out.println(a);
        // System.out.println(b);

        // int a = 3;
        // int b = 6;
        // System.out.println(" ~a is " + ~a); //bitwise NOT operator
        // int result = (~a & b) | (a & ~b);
        // System.out.println(result);  
        
        // if(1) //Type mismatch: cannot convert from int to boolean
        // {
        //     System.out.println("Navin Reddy");           
        // }

        // int x=2;

        // switch(x) {
        // case 1:
        // case 2:
        // case 3:
        // System.out.println("Fly");
        // break;
        // case 4:
        // System.out.println("Swim");}


        // int x = 5;
        // int y = 10;
        // int z = (x++ > 5 && y-- < 10) ? x-- : y;
        // System.out.println("x "+x);
        // System.out.println("y "+y);
        // System.out.println("z "+z);

        // int i, j;
        // i = 100;
        // j = 300;
        // while(++i < --j); //;
        // System.out.println(i);

        // while(++i < --j)
        //     System.out.println(i);
        
        int i = 1;
        while(i<=4) //condition
        {
            System.out.println("hi " + i); 
            i++;
        }
    }

    //NOTES 
    //Which loop executes the code block based on a condition that is checked before each iteration in Java? 
    //WHILE & FOR
    // DO WHILE IS exit-controlled loop
    
}
