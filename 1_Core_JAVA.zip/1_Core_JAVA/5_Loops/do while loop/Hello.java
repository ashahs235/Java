
public class Hello 
{
    public static void main(String[] args) 
    {
        //to execute loop without checking the condition at least once
        //int i = 5;
        int i = 1;
        do
        {
            System.out.println("hi "+i);
            i++;
        }while(i<=4);
        System.out.println(i);
    }
}
