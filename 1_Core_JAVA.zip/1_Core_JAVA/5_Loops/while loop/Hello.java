class Hello
{
    public static void main(String[] args) 
    {
        //repeat the stmt 4 times
        //loops - while, do while, for
        //100 - condition
        //WHILE LOOP CHECKS ONLY FOR CONDITION, NO UPDATION & FINALIZATION
        int i = 1;
        while(true) //infinite loop
        {
            System.out.println("hi " + i); 
            i++;
        }
        
        //simple while loop
        // while(i<=4) //condition
        // {
        //     System.out.println("hi " + i); 
        //     //for every hi, 3 hellos
        //     int j = 1;
        //     while(j<=3)
        //     {
        //         System.out.println("Hello " + j);
        //         j++;
        //     }

        //     i++;
        // }
        // System.out.println("bye "+i);
        
    }
}