// abstract class A
// {
//     public abstract void show();
//     public abstract void config();
// }

//If an abstract class has only abstract methods, we can go for interface

interface A
{
    //variables are final & static, (non static needs heap area but interface don't have their memory in Heap)
    int age = 20;
    String area = "Hubli";

    //all methods in interface are public & abstract, so no need to mention
    void show();
    void config();
}

interface I
{
    void run();
}

interface Y extends A, I
{

}

class B implements Y //A, I //A, Y, I : only methods can be implemented, not variables so variables are final
{

    @Override
    public void show() {
        System.out.println("show");
    }

    @Override
    public void config() {
        System.out.println("config");
    }

    @Override
    public void run() {
        System.out.println("running");
    }
    
}

public class Demo
{
    public static void main(String[] args) 
    {
        A obj = new B();
        obj.config();
        obj.show();

        System.out.println("Area " + A.area); //static variables can be directly used by interface name like class.staticvar
        System.out.println("age " + A.age);

        I obj1 = new B();
        //B obj1 = new B();
        obj1.run();

    }
}

//CLASS - CLASS -> extends
//CLASS - INTERFACE -> implements
//INTERFACE - INTERFACE -> extends