import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class Demo
{
    public static void main(String[] args) 
    {
        int size = 10_000; //total numbers
        List<Integer> nums = new ArrayList<>(size);   //initialCapacity
        Random ran = new Random();
        for(int i=1; i<=size; i++)
        {
            nums.add(ran.nextInt(100)); //all numbers within this number : upper bound
        }
        //System.out.println(nums);

        int sum1 = nums.stream()
                      .map(i -> i*2)
                      .reduce(0, (c, e) -> c+e);

        System.out.println("sum1 "+sum1); //diff sum everytime

        long startSeq = System.currentTimeMillis(); //current milli seconds from 1970s bcoz Unix Epoch came into existence 
        int sum2 = nums.stream()
                      //.map(i -> i*2) 
                      .map(i->{
                          try{Thread.sleep(1);}catch(Exception e){}
                          return i*2;
                      }) 
                      .mapToInt(i->i)   //int stream          
                      .sum(); //internally uses reduce()
                    
        //System.out.println(sum2);

        long endSeq = System.currentTimeMillis();

        //sum() : error initially : The method sum() is undefined for the type Stream<Integer> so use mapToInt()
        //sum() is applicable only when "int stream" is returned, not normal stream

        long startPara = System.currentTimeMillis();
        int sum3 = nums.parallelStream() //parallelStream creates threads
                      //.map(i -> i*2) 
                      .map(i->{
                        try{Thread.sleep(1);}catch(Exception e){}
                        return i*2;
                    })  
                      .mapToInt(i->i)            
                      .sum();
        long endPara = System.currentTimeMillis();
                    
        //System.out.println(sum3);
        //System.out.println(sum1 + " " + sum2 + " " + sum3);
        System.out.println("sums " + sum2 + " " + sum3);

        //since all sums are of same value, so time is calculated : parallelStream runs faster. add some stmts to change time
        //due to delay added : parallelStream takes less time as it is executed by different threads
        //but paraallelStream doesn't work when sorting is needed where values are dependent
        System.out.println("seq : " + (endSeq - startSeq));
        System.out.println("para : " + (endPara - startPara));

        //o/p
            // 987330 987330
            // seq : 11600
            // para : 1928
    }
}