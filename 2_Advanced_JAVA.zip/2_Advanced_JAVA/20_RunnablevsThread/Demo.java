class A implements Runnable
{    
    public void run()
    {
        for(int i=1; i<=10; i++)
        {
            System.out.println("hi");         
            try {
                Thread.sleep(10); 
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }      
    }
}

class B implements Runnable
{
    public void run()
    {
        for(int i=1; i<=10; i++)
        {
            System.out.println("hello");
            try {
                Thread.sleep(10);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }      
    }
}

class Demo
{
    public static void main(String[] args) 
    {
        // A obj1 = new A();    
        // B obj2 = new B();    
        
        //Reference of Interface & object of a class
        Runnable obj1 = new A();  //comment class A & create an instance of Runnable interface & Anonymous class
        // Runnable obj1 = new Runnable(){
        //     public void run()
        //     {
        //         for(int i=1; i<=10; i++)
        //         {
        //             System.out.println("hi");         
        //             try {
        //                 Thread.sleep(10); 
        //             } catch (InterruptedException e) {
        //                 e.printStackTrace();
        //             }
        //         }      
        //     }
        // };

        Runnable obj2 = new B();
 
        //Thread class doesn't know about A & B, so pass Runnable object to Thread constructor
        Thread t1 = new Thread(obj1);
        Thread t2 = new Thread(obj2);

        t1.start(); //t1 bcoz Runnable interface doesn't have start()
        t2.start();
    }
}