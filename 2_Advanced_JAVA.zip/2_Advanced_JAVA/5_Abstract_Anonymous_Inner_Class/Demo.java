abstract class A
{
    public abstract void show(); 
    public abstract void config();   
}

//NO NEED to create B class if show() is used only once
// class B extends A
// {
//     @Override
//     public void show() 
//     {
//         System.out.println("in B show");
//     }   
// }

public class Demo
{
    public static void main(String[] args) 
    {
        A obj = new A()
        {
            public void show()
            {
                System.out.println("hi");
            }

            @Override
            public void config() 
            {
                System.out.println("config");
            }
        };
        obj.show();
        obj.config();
    }
}