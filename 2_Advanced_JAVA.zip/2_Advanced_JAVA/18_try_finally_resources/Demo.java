import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

public class Demo
{
    public static void main(String[] args) throws NumberFormatException, IOException 
    {
        // int i = 0; //0, 1
        // int j = 0;
        // try
        // {
        //     j = 18/i;
        //     System.out.println("try");
        // }

        // catch (Exception e)
        // {
        //     System.out.println("handled");
        //     System.out.println("catch");
        // }

        // finally
        // {
        //     //finally block is executed irrespective of exception is raised or handled or not
        //     //usually used to close the resources
        //     System.out.println("finally");

        // }

        // int num = 0;
        // BufferedReader br = null;
        // try 
        // {
        // //     //InputStreamReader ins = new InputStreamReader(System.in);
        //        //BufferedReader br = new BufferedReader(ins);

        //        //CODE REDUCTION FORM ABOVE 2 STEPS
        //     br = new BufferedReader(new InputStreamReader(System.in));
        //     num = Integer.parseInt(br.readLine());
        //     System.out.println(num);
        //  }
        // finally
        // {           
        //     br.close();
        // }

        //TRY with resources : no need of finally block, declare resource in try block & they r closed automatically
            //navigate through BufferedReader in IDE : closeable
            //the below syntax is shortcut for finally, but it's good to use finally bcoz we'll be clear as to know which resource to close
        int num = 0;
        try(BufferedReader br = new BufferedReader(new InputStreamReader(System.in)))
        {
            num = Integer.parseInt(br.readLine());
            System.out.println(num);
        }
        System.out.println("end");
    }
}