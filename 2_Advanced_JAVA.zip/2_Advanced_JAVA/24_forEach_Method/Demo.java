import java.util.Arrays;
import java.util.List;
import java.util.function.Consumer;

public class Demo
{
    public static void main(String[] args) 
    {
        List<Integer> nums = Arrays.asList(4, 5, 6, 3, 9, 7); //...a is array

        //forEach() takes an object of Consumer : navigate. consumer is SAM accept(): lamda expn
        
        Consumer<Integer> con = new Consumer<Integer>() 
        {
            public void accept(Integer n)
            {
                System.out.println(n);
            }
        };
        //nums.forEach(null); //initial forEach syntax
        nums.forEach(con); //pass con object, forEach gives one value at a time

        //forEach syntax derivation
        Consumer<Integer> con1 =  n -> System.out.println(n);
        nums.forEach(con1); 
        System.out.println("--complete expn--");
        nums.forEach(n -> System.out.println(n));  //instead of con1
        //forEach gives a value "n", with that n we can do anything like print, add, save to database


        //---------------------
        int sum = 0;
        //write any filter logic manually
        for(int n : nums)
        {
            if(n % 2 == 0)
            {
                n = n*2;
                sum = sum + n;
            }
            
        }
        System.out.println(nums);
        System.out.println(sum);

       

        System.out.println("-------foreach loop----------");
        nums.forEach(n -> System.out.println(n));
        
    }
}