import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Scanner;

public class Demo
{
    public static void main(String[] args) throws IOException 
    {
        System.out.println("enter a number"); //PrintStream class : output
        //out is an object inside System class : public static final PrintStream out = null;

        // int num = System.in.read(); //ASCII value
        // System.out.println("ASCII value " + num);
        // System.out.println("actual no " + (num - 48));

        //if no is more than 48, reads only 1st digit
        // enter a number
        // 80
        // ASCII value 56
        // actual no 8

        // SO go for BUFFEREDREADER
        // InputStreamReader ins = new InputStreamReader(System.in); //pass in to bf. InputStreamReader also needs an object, so System.in
        // BufferedReader bf = new BufferedReader(ins); //needs object of reader
        // //readLine() reads String, so parseInt
        //  int num = Integer.parseInt(bf.readLine());
        //  System.out.println("finalised num " + num);

        //  bf.close(); //closing the resources

         //NEW WAY : Scanner 1.5

        Scanner scan =  new Scanner(System.in);
        int num = scan.nextInt();
        System.out.println(num);
 
    }
}