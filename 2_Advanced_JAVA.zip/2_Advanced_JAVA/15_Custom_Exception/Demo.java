class AshaException extends RuntimeException //or Exception
{
    public AshaException(String str)
    {
        //to execute thow in try block
        super(str); //bcoz all exception constructors take String as parameter : navigate through IDE
    }
}

public class Demo
{
    public static void main(String[] args) 
    {
        //int i = 0;
        int i = 20;
        int j = 0;


        try
        {
            j = 18/i; //if exception occurs, rest of the code isn't executed
            if(j==0)
                throw new AshaException("j zero condition"); //Custom Exception
                //No exception of type AshaException can be thrown; an exception type must be a subclass of Throwable : so extends Exception
        }

        //catch(ArithmeticException e) //AshaException isn't getting caught here
        catch(AshaException e)
        {
            j = 19/1;
            System.out.println("different code in catch block " + e);
            //exceptions which are raised in try block are handled in catch block
            //if the exception is not raised, still we want to execute catch block : throw in try block
        }

        
        catch(Exception e) //Parent class of all exceptions
        {
            System.out.println("all exceptions handled here " + e);
        }

        System.out.println(j);

        //Exception in thread "main" java.lang.ArithmeticException: / by zero
        System.out.println("hi");
    }
}