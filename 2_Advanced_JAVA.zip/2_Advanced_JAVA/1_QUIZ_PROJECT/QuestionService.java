import java.util.Scanner;

public class QuestionService 
{
    Question[] questions = new Question[6];
    String selection[] = new String[6];
    
    public void displayQuestions()
    {
        //System.out.println(questions[0].getQuestion()); //questions, questions[0]
        //above syntax is reference of the questions not the object, so create the object to initialise in constructor otherwise java.lang.NullPointerException
        
        for(Question q : questions)
        {
           // System.out.println(q.getId() + " " + q.getQuestion());
           System.out.println(q); //hashcode kind of, so use toString()
        }
        //System.out.println(questions[1].getQuestion()); //null initially
    }

    //create Constructor & manually create objects
    public QuestionService()
    {
        //questions[0] = new Question();
        //System.out.println(questions[0].getQuestion()); //null initially
        questions[0] = new Question(1, "What", "Java", "CPP", "C", "Python", "Java");
        questions[1] = new Question(2, "size of int", "2", "6", "4", "8", "4");
        questions[2] = new Question(3, "size of double", "2", "6", "4", "8", "8");
        questions[3] = new Question(4, "size of char", "2", "6", "4", "8", "2");
        questions[4] = new Question(5, "size of long", "2", "6", "4", "8", "8");
        questions[5] = new Question(6, "size of boolean", "1", "2", "4", "8", "1");
        //System.out.println(questions[4].getQuestion());
    }

    //input from user
    public void playQuiz()
    {
        int i=0;
        for(Question q : questions)
        {         
           System.out.println("Question no : " + q.getId()); //System.out is output
           System.out.println(q.getQuestion());
           System.out.println(q.getOpt1()); 
           System.out.println(q.getOpt2());
           System.out.println(q.getOpt3());
           System.out.println(q.getOpt4());

           Scanner sc = new Scanner(System.in); //System.in is input
           selection[i] = sc.nextLine(); //nextLine() is taking the input from user in console,
           //if the above variable selection is NOT an array, its value changes everytime : new answer when d questions run
           //so array means all answers will be stored
           i++; //new answer to the next index
        }
        System.out.println("---USER ANSWER---");
        for(String s : selection)
        {           
            System.out.println("all answers given by user " + s);
        }
    }

    public void printScore()
    {
        int score = 0;
        for(int i=0; i<questions.length; i++)
        {
            Question que = questions[i];
            String actualAnswer = que.getAnswer();
            String userAnswer = selection[i];

            if(actualAnswer.equals(userAnswer))
            {
                score++;
            }
        }
        System.out.println("Score is :" + score);
        System.out.println("--------------------");
        for(Question q : questions)
        {
            System.out.println("correct answers " + q.getAnswer());
        }
    }
}
