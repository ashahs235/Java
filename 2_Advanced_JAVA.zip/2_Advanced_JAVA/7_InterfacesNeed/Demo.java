// abstract class Computer
// {
//     abstract public void code();
//     //{
//         //empty bcoz computer doesn't exist : just a concept : either laptop or desktop : so extends
//         //empty implementation - make it abstract
//         //an abstract class with only abstract methods can be declared as interface
//         //make sub clases implements
//     //}
// }

interface Computer
{
    void code();
}

class Laptop implements Computer
{
    public void code()
    {
        System.out.println("code, compile, run");
    }
}

class Desktop implements Computer
{
    public void code()
    {
        System.out.println("code, compile, run faster on desktop ");
    }
}

//Developer needs a Laptop/desktop in an organization, so pass it as a parameter
class Developer //developer isn't dependent on laptop/desktop, it's dependent on computer
{
    public void devApp(Computer lap) //(Laptop lap) : tightly coupled to Laptop, so computer is better bcoz it can either laptop or desktop -- loosely coupled
    {
        lap.code();
    }
}

public class Demo
{
    public static void main(String[] args) 
    {
        Computer lap = new Laptop(); //interface references
        lap.code();
        Computer desk = new Desktop();
        Laptop l = new Laptop();
        Developer dev = new Developer();
        dev.devApp(desk);

        Computer lapdesk = new Laptop();
        System.out.println("--");
        dev.devApp(lapdesk);
    }
}