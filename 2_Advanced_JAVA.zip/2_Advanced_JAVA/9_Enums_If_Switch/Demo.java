enum Status 
{
    Running, Failed, Pending, Success; //named constants
}
//status is a class in java

public class Demo
{
    public static void main(String[] args) 
    {
        Status s = Status.Success;

        System.out.println("Class " + s.getClass().getSuperclass());
        System.out.println(s.getClass());
        System.out.println(s.getClass().getSuperclass());

        switch(s)
        {
            case Running :
                System.out.println("all good");
                break;
            
            case Failed :
                System.out.println("try again");
                break;

            case Pending :
                System.out.println("pls wait");
                break;

            default :
                System.out.println("done");
                break;
        }

        System.out.println("------");

        if(s == Status.Running)
            System.out.println("All good");
        else if(s == Status.Failed)
            System.out.println("try again");
        else if(s == Status.Pending)
            System.out.println("Pls wait");
        else
            System.out.println("Done");
        
    }
}