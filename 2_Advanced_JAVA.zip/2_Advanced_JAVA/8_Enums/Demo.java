enum Status 
{
    Running, Failed, Pending, Success; //named constants
}
//status is a class in java

public class Demo
{
    public static void main(String[] args) 
    {
        Status s = Status.Running;
        Status s1 = Status.Success;
        System.out.println(s);
        System.out.println(s.ordinal()); //numbering - 0

        Status[] s_all = Status.values(); //[] bcoz array
        System.out.println(s_all); //[LStatus;@36baf30c
        System.out.println(s_all[0]);

        System.out.println();
        System.out.println("all Status");
        for(Status stat : s_all)
        {           
            System.out.println(stat + " : " + stat.ordinal());
        }
    }
}