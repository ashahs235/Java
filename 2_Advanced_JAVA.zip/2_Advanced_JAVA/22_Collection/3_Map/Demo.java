import java.util.HashMap;
import java.util.Hashtable;
import java.util.Map;

public class Demo
{
    public static void main(String[] args) 
    {
        //<K, V>
        //keys are set : unique
        //values are list
        //put() bcoz if we call add(), it's adding elements, 
        //put means "add the element, if key is already there, replace it"
        //Map<String, Integer> students = new HashMap<>();
        Map<String, Integer> students = new Hashtable<>();
        //Hashmap & Hashtable are same but hashtable is synchronized
        students.put("asha1", 1);
        students.put("asha2", 2);
        students.put("asha3", 3);
        students.put("asha4", 4);
        students.put("asha2", 21); //if key is duplicated, recent key, value is printed

        System.out.println(students); //not a sequence
        System.out.println(students.get("asha3"));

        System.out.println("all keys " + students.keySet() + " all values " + students.values());
        //students.keySet() is an array

        for(String key : students.keySet())
        {
            System.out.println(key + " : " + students.get(key));
        }
    }
}