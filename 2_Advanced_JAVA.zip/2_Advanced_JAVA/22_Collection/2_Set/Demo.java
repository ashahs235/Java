import java.util.Collection;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;
import java.util.TreeSet;

public class Demo
{
    public static void main(String[] args) 
    {
        // Set<Integer> nums = new HashSet<Integer>(); //no index & no sequence
        // Set<Integer> nums = new TreeSet<Integer>(); //sorted values 
        
        // nums.add(6);
        // nums.add(9);
        // nums.add(5);
        // nums.add(3);
        // nums.add(6);

        // nums.add(61);
        // nums.add(94);
        // nums.add(56);
        // nums.add(82);
        // nums.add(61);

        // for(int n : nums)
        // {
        //     System.out.println(n);
        // }

        Collection<Integer> nums = new HashSet<Integer>(); //Collection also can be used

        nums.add(61);
        nums.add(94);
        nums.add(56);
        nums.add(82);
        nums.add(61);

        //navigate through Collection > iterable > iterator
        Iterator<Integer> values = nums.iterator();
        
        //System.out.println("one " + values.next()); //one element

        while(values.hasNext())
          System.out.println("next " + values.next());

    }
}