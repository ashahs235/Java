import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;


class Student implements Comparable<Student> 
{
    int age;
    String name;

    public Student(int age, String name) {
        this.age = age;
        this.name = name;
    }

    @Override
    public String toString() {
        return "Student [age=" + age + ", name=" + name + "]";
    }

    @Override
    public int compareTo(Student that) 
    {
        if(this.age > that.age)
            return 1; //1 is swap
        else
            return -1;
    }
}

public class Demo
{
    public static void main(String[] args) 
    {
        //Integer CODE
        Comparator<Integer> com = new Comparator<Integer>() 
        {
            public int compare(Integer i, Integer j)
            {
                if(i%10 > j%10)
                    return 1; //1 is swap
                else
                    return -1;
            }
        };
        List<Integer> nums = new ArrayList<>();
        nums.add(43);
        nums.add(31);  
        nums.add(92);    
        nums.add(84);  

        System.out.println(nums);

        //to SORT : Collections class
        Collections.sort(nums); //Integer class has sort() : navigate. but student class doesn't hav, so Student implements Comparable 
        System.out.println(nums);
        Collections.sort(nums, com);
        System.out.println(nums);
        System.out.println("----------------------");

        //1
        //STUDENT CODE
        //below logic need not be for Comparable
        Comparator<Student> comS = new Comparator<Student>() 
        {
            //Comparator has compare() : we provided logic on how the elements should be sorted
            //Comparator is an interface using which we can specify our own logic for sorting
            public int compare(Student i, Student j)
            {
                if(i.age > j.age)
                    return 1; //1 is swap
                else
                    return -1;
            }
        };
        

        List<Student> studs = new ArrayList<>();
        studs.add(new Student(21, "Asha"));
        studs.add(new Student(23, "Asha1"));
        studs.add(new Student(24, "Asha2"));
        studs.add(new Student(12, "Asha3"));

        System.out.println(studs);
        
        //implementing Comparable & overriding comapareTo()
        Collections.sort(studs); //Integer class has sort() : navigate. but student class doesn't hav, 
        //so Student implements Comparable without comS also works bcoz Comparable Lists (and arrays) of objects that implement this interface can be sorted automatically
        System.out.println(studs);
        System.out.println("--------");
        //2
        Collections.sort(studs, comS);
        System.out.println(studs);
        System.out.println("--------");
        for(Student s : studs)
            System.out.println("studs " + s);
    }
}