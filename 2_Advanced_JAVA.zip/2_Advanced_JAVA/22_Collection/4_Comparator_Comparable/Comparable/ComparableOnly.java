import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;


class Student implements Comparable<Student> 
{
    int age;
    String name;

    public Student(int age, String name) {
        this.age = age;
        this.name = name;
    }

    @Override
    public String toString() {
        return "Student [age=" + age + ", name=" + name + "]";
    }

    @Override
    public int compareTo(Student that) 
    {
        if(this.age > that.age)
            return 1; //1 is swap
        else
            return -1;
    }
}

public class ComparableOnly
{
    public static void main(String[] args) 
    {

        List<Student> studs = new ArrayList<>();
        studs.add(new Student(21, "Asha"));
        studs.add(new Student(23, "Asha1"));
        studs.add(new Student(24, "Asha2"));
        studs.add(new Student(12, "Asha3"));

        System.out.println(studs);
        
        //implementing Comparable & overriding comapareTo()
        Collections.sort(studs); //Integer class has sort() : navigate. but student class doesn't hav, 
        //so Student implements Comparable without comS also works bcoz Comparable Lists (and arrays) of objects that implement this interface can be sorted automatically
        System.out.println(studs);
        
        for(Student s : studs)
            System.out.println("studs " + s);
    }
}