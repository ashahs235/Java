import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;


class Student
{
    int age;
    String name;

    public Student(int age, String name) {
        this.age = age;
        this.name = name;
    }

    @Override
    public String toString() {
        return "Student [age=" + age + ", name=" + name + "]";
    }
    
}

public class Demo
{
    public static void main(String[] args) 
    {
        //Integer CODE
        Comparator<Integer> com = new Comparator<Integer>() 
        {
            //Comparator has compare() : we provided logic on how the elements should be sorted
            //Comparator is an interface using which we can specify our own logic for sorting
            public int compare(Integer i, Integer j)
            {
                //swapping based on last digit
                if(i%10 > j%10)
                    return 1; //1 is swap
                else
                    return -1;
            }
        };
        List<Integer> nums = new ArrayList<>();
        nums.add(43);
        nums.add(31);  
        nums.add(92);    
        nums.add(84);  

        System.out.println(nums);

        //to SORT : Collections class
        Collections.sort(nums); //Integer implements Comparable & has sort() : navigate. but student class doesn't hav, so we need to make Student implements Comparable 
        System.out.println(nums);

        Collections.sort(nums, com);
        System.out.println(nums);

        System.out.println("----------------------");

        //STUDENT CODE

        Comparator<Student> comS = new Comparator<Student>() 
        {
            //Comparator has compare() : we provided logic on how the elements should be sorted
            //Comparator is an interface using which we can specify our own logic for sorting
            public int compare(Student i, Student j)
            {
                if(i.age > j.age)
                    return 1; //1 is swap
                else
                    return -1;
            }
        };

        List<Student> studs = new ArrayList<>();
        studs.add(new Student(21, "Asha"));
        studs.add(new Student(23, "Asha1"));
        studs.add(new Student(24, "Asha2"));
        studs.add(new Student(12, "Asha3"));

        System.out.println(studs);
        Collections.sort(studs, comS); //Integer class has sort() : navigate. but student class doesn't hav, so Student implements Comparable or pass comS 
        for(Student s : studs)
            System.out.println("studs " + s);

    }
}