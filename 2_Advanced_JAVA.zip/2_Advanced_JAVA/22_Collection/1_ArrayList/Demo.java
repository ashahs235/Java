import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

public class Demo
{
    public static void main(String[] args) 
    {
        //Collection is an interface, if we create object of Collection, we have to implement all of its methods (navigate in IDE), so inbuilt classes (no need of anonymous class creation on our own as we have inbuilt classes)
        //Collection nums = new ArrayList(); //if type isn't mentioned, they are Objects, error in for loop when int is declared, so GENERICS

        //Collection<Integer> nums = new ArrayList<Integer>();
        //Collection has methods used to add values & fetch

        //to get the index of the values : List bcoz List has get method (Navigate)
        List<Integer> nums = new ArrayList<Integer>();
        nums.add(6);
        nums.add(9);
        nums.add(5);
        nums.add(3);
        
        nums.add(9);
        nums.add(76);
        //nums.add("2");

        //NO NEED of LOOP to print the elements like ARRAY
        //Directly print a COLLECTION
        //System.out.println(nums);
        System.out.println("index " + nums.get(2));
        System.out.println("index of " + nums.indexOf(9));
        nums.set(2, 34); //value is replaced
        //nums.set(4, 44); //Runtime exception java.lang.IndexOutOfBoundsException
        System.out.println(nums);

        //WITHOUT <Integer>
        for(Object n : nums) //n is object, so typecast
        {
            int n1 = (Integer)n;
            System.out.println(n1);
            System.out.println(n1*2);
            //Runtime Exception if nums.add("2")
            //if <Integer> is mentioned, compile time error
        }

        for(int n : nums)
        {
            System.out.println(n);
        }
    }
}