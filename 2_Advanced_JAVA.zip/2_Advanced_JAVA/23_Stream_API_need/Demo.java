import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Stream;

public class Demo
{
    public static void main(String[] args) 
    {
        // List<Integer> nums = new ArrayList<>();
        // nums.add(4);  
        // nums.add(5); 
        // nums.add(6);   
        // nums.add(7); 

        //instead of manually typing, we can use Arrays.asList(1, 2, 3, 4)
        List<Integer> nums = Arrays.asList(4, 5, 6, 3, 9, 7); //...a is array

        int sum = 0;
        //write any filter logic manually
        for(int n : nums)
        {
            if(n % 2 == 0)
            {
                n = n*2;
                sum = sum + n;
            }
            
        }
        System.out.println("nums array " + nums);
        System.out.println("sum " + sum);

        for(int i = 0; i<nums.size(); i++)
        {
            System.out.println(nums.get(i));
        }

        System.out.println("-------enhanced for loop----------");

        for(int n : nums)
        {
            System.out.println(n);
        }

        System.out.println("-------foreach loop----------");
        nums.forEach(n -> System.out.println(n));
        
    }
}