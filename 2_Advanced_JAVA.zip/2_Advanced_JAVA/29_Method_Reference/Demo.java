import java.util.Arrays;
import java.util.List;

public class Demo
{
    public static void main(String[] args) 
    {
        List<String> names = Arrays.asList("Asha", "Yash", "Ashvik");

        //to change the case to uppercase
        List<String> uNames = names.stream()
                                   //.map(name->name.toUpperCase()) //name is a local variable
                                   //changing the above syntax : Method reference : mention only method name & to where that method belongs to (which class)
                                   .map(String::toUpperCase)
                                   .toList();    //return stream in a List format

        System.out.println(uNames);
        uNames.forEach(n->System.out.println(n));
        //OR
        uNames.forEach(System.out::println);
    }
}