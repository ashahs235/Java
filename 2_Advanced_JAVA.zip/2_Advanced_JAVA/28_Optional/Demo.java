import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

public class Demo
{
    public static void main(String[] args) 
    {
        List<String> names = Arrays.asList("Asha1", "Asha", "Asha2", "Asha4");

        //Stream method that has 1 in names, Optional null check
        Optional<String> nameO = names.stream()
                                     .filter(str -> str.contains("p"))
                                     .findFirst();

        //System.out.println(name.get()); //java.util.NoSuchElementException sometimes
        System.out.println(nameO.orElse("not found by using optional"));


        //WITHOUT OPTIONAL
        String nameS = names.stream()
                           .filter(str -> str.contains("s"))
                           .findFirst()
                           .orElse("not found");

        System.out.println("name found without optional " + nameS);
            
    }
}
