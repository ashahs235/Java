class A
{
    public void show()
    {
        System.out.println("in A show");
    }
}

//to change the behaviour of show(), either override in child class or anonymous inner class 
//bcoz changed show() method is used only once. method overriding is needed if the show() is used multiple times

// class B extends A
// {
//     public void show()
//     {
//         System.out.println("in B show");
//     }
// }

class Demo
{
    public static void main(String[] args) 
    {
        A obj = new A()
        //Anonymous inner class (used only once & is created inside Demo class without name) : create object first & then implementation 
        //(usually first create class & then create object)
        {
            public void show()
            {
                System.out.println("in new show");
            }
        };
        obj.show();
        obj.show();         
    }
    //A.show(); //ERROR
}