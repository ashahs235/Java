class A
{
    public void show() throws ClassNotFoundException
    {
        // try
        // {
        //     Class.forName("Calc"); //Calc, Demo
        // }
        // catch(ClassNotFoundException e)
        // {
        //     System.out.println("no class");
        // }

        //Without try catch, throws
        Class.forName("Calc"); //Calc, Demo
    }
}

public class Demo
{
    static
    {
        System.out.println("Class loaded");
    }
    public static void main(String[] args) //throws ClassNotFoundException : throws not suitable for main() bcoz JVM might shutdown
    {
        A obj = new A();
        try {
            obj.show();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
    }
}