@FunctionalInterface
interface A
{
    void show(int i, int j);
}

@FunctionalInterface
interface B
{
    void showB(int b);
}

@FunctionalInterface
interface C
{
    int add(int m, int n);
}

// class B implements A
// {
//     public void show(int i, int j)
//     {
//         System.out.println("in show " + (i+j) );
//     }
// }

//use anonymous inner class in Demo
//verbose : detailed code upto java 7
//java 8 : code reduction

//We can use Lambda expression only with Functional interface

public class Demo
{
    public static void main(String[] args) 
    {
        // A obj = new A()
        // {
        //     public void show(int i, int j)
        //     {
        //         System.out.println("in show " + (i+j));
        //     }
        // };
        // obj.show(5, 8);

        // A obj = (int i, int j) -> //arrow mark is lambda expression 
        //     {
        //         System.out.println("in show" + (i+j));
        //     }
        // ; //one line - remove curly brackets & ;

        //(int i, int j)
        A obj = (i, j) -> System.out.println("in show " + (i+j));   
        obj.show(5, 7);

        B ob = b -> System.out.println("B " +b); //no need of ( ) for b as it's one parameter
        ob.showB(3);

        // C c = new C()
        // {
        //     @Override
        //     public int add(int m, int n) 
        //     {
        //         // TODO Auto-generated method stub
        //         //throw new UnsupportedOperationException("Unimplemented method 'add'");
        //         return m+n; //curly bracket with return type is right
        //     }          
        // };

        //C c = (int m, int n)  -> return (m+n); //error bcoz of return
        C c = (m, n)  ->  m+n; //the expression m+n becomes return value
        int result = c.add(4, 5);
        System.out.println("C " +result);

    }
}