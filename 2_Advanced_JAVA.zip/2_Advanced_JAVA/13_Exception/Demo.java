public class Demo
{
    public static void main(String[] args) 
    {
        int i = 0;
        //int i = 4;
        int j = 0;

        int nums[] = new int[5]; //length is 5, 0 to 4 index
        //String str = ""; //0
        String str = null;

        try
        {
            j = 18/i; //if exception occurs, rest of the code isn't executed
            System.out.println(nums[1]);
            System.out.println(nums[4]);
            //System.out.println("str " + str.length());
            System.out.println(nums[5]); //java.lang.ArrayIndexOutOfBoundsException: Index 5 out of bounds for length 5
            System.out.println("try"); //not executed for i=0
        }

        catch(ArithmeticException e)
        {
            System.out.println("handled : cannot divide by zero " + e); //
        }

        catch(ArrayIndexOutOfBoundsException e)
        {
            System.out.println("enter within array range" + e);
        }

        catch(Exception e) //Parent class of all exceptions
        {
            System.out.println("all exceptions handled here" + e);
        }

        System.out.println(j);

        //Exception in thread "main" java.lang.ArithmeticException: / by zero
        System.out.println("hi"); //not displayed
    }
}