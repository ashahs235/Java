import java.util.Arrays;
import java.util.List;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.stream.Stream;

public class Demo
{
    public static void main(String[] args) 
    {
        List<Integer> nums = Arrays.asList(4, 5, 6, 3, 8, 7);
        Stream<Integer> s1 = nums.stream();
        //System.out.println(s1);

        //Stream METHODS EXPLANATION
        //1)filter : navigate filter
        //Stream<T> filter(Predicate<? super T> predicate);
        // Predicate<Integer> p = new Predicate<Integer>() {

        //     @Override
        //     public boolean test(Integer n) 
        //     {
        //         // if (n%2==0)
        //         //     return true;
        //         // else
        //         //     return false;

        //         return (n%2==0);
        //     }           
        // };

        Predicate<Integer> p = n->n%2==0;

        //2) map
        //<R> Stream<R> map(Function<? super T, ? extends R> mapper);
        //Function takes 2 parameters, 1st is accepting parameter, 2nd is returning parameter
        // Function<Integer, Integer> fun = new Function<Integer, Integer>() {
        //     public Integer apply(Integer n) {
        //         return n*2;
        //     }           
        // };

        Function<Integer, Integer> fun = n -> n*2;

        //3) reduce
        //usually to add a series of numbers, we add 2 numbers at a time
        //0 is initial value, c & e are the 2 numbers to add : see word doc
 
        int combinedResult = nums.stream()
                                 .filter(n->n%2==0)
                                 //.filter(p)
                                 .map(n -> n*2)
                                 //.map(fun)
                                 .reduce(0, (c, e) -> c+e);

        System.out.println("combinedResult " + combinedResult); 
        
        //below code is used to sort elements but of one thread
        //if 2 threads, use nums.parallelStream(), 
        //but if we use parallelStream(), sorted() shouldn't be used as sorting needs all values from 2 threads
        Stream<Integer> sortedValues = nums.stream()
                                           .filter(n->n%2==0)
                                           //.map(n->n*2)
                                           .sorted();
                            
        //System.out.println("sortedValues " + sortedValues);
        //printing Stream gives o/p : java.util.stream.SortedOps$OfRef@3e3abc88

        sortedValues.forEach(n->System.out.println(n));
    }
}