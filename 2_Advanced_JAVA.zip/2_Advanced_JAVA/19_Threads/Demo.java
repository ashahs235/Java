class A extends Thread
{
    //public void show()
    public void run()
    {
        for(int i=1; i<=10; i++)
        {
            System.out.println("hi");

            //sleep method
            try {
                Thread.sleep(10); //one thread after another
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }      
    }
}

class B extends Thread
{
    //public void show()
    public void run()
    {
        for(int i=1; i<=10; i++)
        {
            System.out.println("hello");
            try {
                Thread.sleep(10);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }      
    }
}

class Demo
{
    public static void main(String[] args) 
    {
        A obj1 = new A();
        //obj1.show(); //sequential execution
        obj1.start(); //parallel execution


        try {
            Thread.sleep(2);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        B obj2 = new B();
        //obj2.show();
        obj2.start(); //obj1 & obj2 are threads now
        //start() calls run()

        //sequential execution initially
        //we want both method/behaviour : extend Thread class
        //even after extending Thread class, still sequential execution happens, so to make parallel execution : instead of show, call start()

        //to make the threads execute one after the other
        System.out.println("t1 " + obj1.getPriority());

        obj2.setPriority(Thread.MAX_PRIORITY); //10
        System.out.println("t2 " + obj2.getPriority());

        //priority range is 1-10
    }
}