//inner classes B & C belong to outer class A, inner classes can be declared static but not outer class
//bcoz Illegal modifier for the class A; only public, abstract & final are permitted

class A
{
    int age;
    public void show()
    {
        System.out.println("in A show");
    }

    class B
    {
        public void config() //if show() : void A.B.show()
        {
            System.out.println("in B config");
        }
    }

    static class C 
    {
        public void cstatic()
        {
            System.out.println("in C static");
        }
    }
}

class Demo
{
    public static void main(String[] args) 
    {
        A obj = new A();
        obj.show();

        //B obj1 = new B(); //ERROR : B cannot be resolved to a type bcoz B cannot be openly available, B belongs to A
        //A.B obj1 = new A.B(); //ERROR
        //No enclosing instance of type A is accessible. Must qualify the allocation with an enclosing instance of type A (e.g. x.new A() where x is an instance of A).
        
        //to create object of B, we need object of A first
        A.B obj1 = obj.new B();
        obj1.config();

        A.C obj2 = new A.C(); //static class C
        obj2.cstatic();
    }
}