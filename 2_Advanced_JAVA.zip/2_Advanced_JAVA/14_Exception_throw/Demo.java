public class Demo
{
    public static void main(String[] args) 
    {
        //int i = 0;
        int i = 20; //20, so quotient is zero : throw
        //int j = 1;
        int j = 0;

        try
        {
            j = 18/i; //if exception occurs, rest of the code isn't executed
            if(j==0)
                throw new ArithmeticException("bcoz j is zero"); // constructor message bcoz "/ by zero" is not the case in Arithmetic exception here
                //like "/ by zero", we customised message
                //THROW keyword is used to throw an Exception, catch block will handle it
                //new ArithmeticException : we created an error
        }

        catch(ArithmeticException e)
        {
            j = 18/1;
            System.out.println("different code in catch block " + e);
            //exceptions which are raised in try block are handled in catch block
            //if the exception is not raised, still we want to execute catch block : throw in try block
            //even if the catch block is NOT called, we'll still call it bcoz in catch block, we handle the exception
        }   

        
        catch(Exception e) //Parent class of all exceptions
        {
            System.out.println("all exceptions handled here" + e);
        }

        System.out.println("j " + j);

        //Exception in thread "main" java.lang.ArithmeticException: / by zero
        System.out.println("hi"); //not displayed
    }
}