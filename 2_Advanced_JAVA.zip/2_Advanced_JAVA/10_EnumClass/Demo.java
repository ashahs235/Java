enum Laptop
{
    Macbook(2000), XPS(2200), Surface, ThinkPad(1800); //error initially, so create constructor

    //Laptop is class, all Macbook, XPS .. are objects, different objects with different prices
    //In this code, the Laptop enum defines a set of constants (Macbook, XPS, Surface, and ThinkPad), 
    //each representing different laptops. 
    //These constants are treated as objects, and constructors are used to assign prices to each of these enum values.


    private int price;

    //called once
    private Laptop() {
        //price = 500; //if not mentioned, surface : 0
        System.out.println("default constructor " + this.name());
    }

    //called thrice
    private Laptop(int price) {
        this.price = price;
        System.out.println("in Laptop " + this.name());
    }

    public int getPrice() {
        return price;
    }

    public void setPrice(int price) {
        this.price = price;
    }   
}

public class Demo
{
    public static void main(String[] args) 
    {
         Laptop lap = Laptop.Macbook;
         System.out.println("-------------");
         //Laptop xps = Laptop.XPS; //not executed
        System.out.println(lap + " : " + lap.getPrice());

        for(Laptop l : Laptop.values())
        {
            System.out.println(l + " : " + l.getPrice());
        }
    }
}